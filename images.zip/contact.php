<?php
// contact.php - Simple contact page, perhaps with form for inquiring about a car
require_once 'config.php';

// Placeholder for form submission (you can implement actual email sending)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Invalid token');
    } else {
        // Validate inputs
        $name = clean($_POST['name']);
        $email = clean($_POST['email']);
        $subject = clean($_POST['subject']);
        $message = clean($_POST['message']);
       
        if (validateEmail($email) && !empty($name) && !empty($subject) && !empty($message)) {
            // Send email (placeholder)
            // mail('kabuteyautoltd@gmail.com', $subject, $message, "From: $email");
            setFlash('success', 'Your message has been sent!');
        } else {
            setFlash('error', 'Please fill all fields correctly.');
        }
    }
    redirect('contact.php');
}

$carId = intval($_GET['car_id'] ?? 0);
$car = $carId ? getCarById($carId) : null;

$error = getFlash('error');
$success = getFlash('success');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - <?php echo SITE_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e293b',
                        secondary: '#334155',
                        accent: '#ea580c',
                    },
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <div class="flex items-center">
                    <a href="index.php" class="text-2xl font-bold text-primary">
                        <i class="fas fa-car text-accent mr-2"></i><?php echo SITE_NAME; ?>
                    </a>
                </div>
               
                <div class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-accent transition font-medium">Home</a>
                    <a href="cars.php" class="text-gray-700 hover:text-accent transition font-medium">All Cars</a>
                    <a href="about.php" class="text-gray-700 hover:text-accent transition font-medium">About</a>
                    <a href="contact.php" class="text-gray-700 hover:text-accent transition font-medium">Contact</a>
                    <?php if (isLoggedIn()): ?>
                        <a href="admin/dashboard.php" class="bg-accent text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition">
                            <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-700 hover:text-accent transition font-medium">
                            <i class="fas fa-user mr-1"></i>Admin
                        </a>
                    <?php endif; ?>
                </div>
               
                <!-- Mobile menu button -->
                <button id="mobile-menu-btn" class="md:hidden text-gray-700 hover:text-accent">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
       
        <!-- Mobile menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-white border-t">
            <div class="px-4 pt-2 pb-4 space-y-2">
                <a href="index.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Home</a>
                <a href="cars.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">All Cars</a>
                <a href="about.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">About</a>
                <a href="contact.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Contact</a>
                <?php if (isLoggedIn()): ?>
                    <a href="admin/dashboard.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Dashboard</a>
                <?php else: ?>
                    <a href="login.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Admin Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
   
    <!-- Contact Section -->
    <section class="pt-32 pb-16 bg-gray-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 animate__animated animate__fadeIn">
                <h1 class="text-4xl font-bold text-primary mb-4">Contact Us</h1>
                <p class="text-xl text-gray-600">Get in touch for any inquiries</p>
            </div>
           
            <?php if ($error): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded-lg mb-6 flex items-center animate__animated animate__fadeIn">
                <i class="fas fa-exclamation-circle mr-2"></i><?php echo $error; ?>
            </div>
            <?php endif; ?>
            <?php if ($success): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded-lg mb-6 flex items-center animate__animated animate__fadeIn">
                <i class="fas fa-check-circle mr-2"></i><?php echo $success; ?>
            </div>
            <?php endif; ?>
           
            <div class="grid grid-cols-1 md:grid-cols-2 gap-12">
                <!-- Contact Info -->
                <div class="bg-white rounded-2xl shadow-xl p-8 animate__animated animate__fadeInLeft">
                    <h2 class="text-2xl font-bold text-primary mb-6">Our Contact Information</h2>
                    <ul class="space-y-4 text-gray-600">
                        <li class="flex items-center">
                            <i class="fas fa-map-marker-alt text-accent mr-4 text-2xl"></i>
                            Accra, Ghana
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-phone text-accent mr-4 text-2xl"></i>
                            +233202493547
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-envelope text-accent mr-4 text-2xl"></i>
                            kabuteyautoltd@gmail.com
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-clock text-accent mr-4 text-2xl"></i>
                            Mon - Fri: 9AM - 6PM
                        </li>
                    </ul>
                   
                    <div class="mt-8">
                        <h3 class="text-xl font-bold text-primary mb-4">Follow Us</h3>
                        <div class="flex space-x-4">
                            <a href="#" class="text-2xl text-gray-600 hover:text-accent transition"><i class="fab fa-facebook"></i></a>
                            <a href="#" class="text-2xl text-gray-600 hover:text-accent transition"><i class="fab fa-twitter"></i></a>
                            <a href="#" class="text-2xl text-gray-600 hover:text-accent transition"><i class="fab fa-instagram"></i></a>
                            <a href="#" class="text-2xl text-gray-600 hover:text-accent transition"><i class="fab fa-linkedin"></i></a>
                        </div>
                    </div>
                </div>
               
                <!-- Contact Form -->
                <div class="bg-white rounded-2xl shadow-xl p-8 animate__animated animate__fadeInRight">
                    <h2 class="text-2xl font-bold text-primary mb-6">Send Us a Message<?php if ($car): ?> about the <?php echo clean($car['year'] . ' ' . $car['make'] . ' ' . $car['model']); ?><?php endif; ?></h2>
                   
                    <form method="POST" class="space-y-6">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Your Name</label>
                            <input type="text" name="name" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition" placeholder="John Doe">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Your Email</label>
                            <input type="email" name="email" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition" placeholder="john@example.com">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                            <input type="text" name="subject" required value="<?php echo $car ? 'Inquiry about ' . clean($car['year'] . ' ' . $car['make'] . ' ' . $car['model']) : ''; ?>"
                                   class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition" placeholder="Your subject">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Message</label>
                            <textarea name="message" rows="6" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition" placeholder="Your message here..."></textarea>
                        </div>
                       
                        <button type="submit" class="w-full bg-accent text-white py-4 rounded-lg font-semibold hover:bg-orange-700 transition">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>
   
    <!-- Footer -->
    <footer class="bg-primary text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-2xl font-bold mb-4">
                        <i class="fas fa-car text-accent mr-2"></i><?php echo SITE_NAME; ?>
                    </h3>
                    <p class="text-gray-300">Your trusted partner in finding quality vehicles.</p>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Quick Links</h4>
                    <ul class="space-y-2">
                        <li><a href="index.php" class="text-gray-300 hover:text-accent transition">Home</a></li>
                        <li><a href="cars.php" class="text-gray-300 hover:text-accent transition">All Cars</a></li>
                        <li><a href="about.php" class="text-gray-300 hover:text-accent transition">About</a></li>
                        <li><a href="contact.php" class="text-gray-300 hover:text-accent transition">Contact</a></li>
                    </ul>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Contact</h4>
                    <ul class="space-y-2 text-gray-300">
                        <li><i class="fas fa-phone text-accent mr-2"></i>+233202493547</li>
                        <li><i class="fas fa-envelope text-accent mr-2"></i>kabuteyautoltd@gmail.com</li>
                        <li><i class="fas fa-map-marker-alt text-accent mr-2"></i>123 Auto St, City</li>
                    </ul>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Follow Us</h4>
                    <div class="flex space-x-4">
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
            </div>
           
            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>
   
    <script>
        // Mobile menu toggle
        document.getElementById('mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('mobile-menu').classList.toggle('hidden');
        });
    </script>
</body>
</html>