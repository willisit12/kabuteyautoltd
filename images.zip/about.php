<?php
// about.php - Simple about page
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - <?php echo SITE_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e293b',
                        secondary: '#334155',
                        accent: '#ea580c',
                    },
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <div class="flex items-center">
                    <a href="index.php">
                        <img src="images/logo-main.png" alt="<?php echo SITE_NAME; ?>" class="h-16 object-contain">
                    </a>
                </div>
               
                <div class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-accent transition font-medium">Home</a>
                    <a href="cars.php" class="text-gray-700 hover:text-accent transition font-medium">All Cars</a>
                    <a href="about.php" class="text-gray-700 hover:text-accent transition font-medium">About</a>
                    <a href="contact.php" class="text-gray-700 hover:text-accent transition font-medium">Contact</a>
                    <?php if (isLoggedIn()): ?>
                        <a href="admin/dashboard.php" class="bg-accent text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition">
                            <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-700 hover:text-accent transition font-medium">
                            <i class="fas fa-user mr-1"></i>Admin
                        </a>
                    <?php endif; ?>
                </div>
               
                <!-- Mobile menu button -->
                <button id="mobile-menu-btn" class="md:hidden text-gray-700 hover:text-accent">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
       
        <!-- Mobile menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-white border-t">
            <div class="px-4 pt-2 pb-4 space-y-2">
                <a href="index.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Home</a>
                <a href="cars.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">All Cars</a>
                <a href="about.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">About</a>
                <a href="contact.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Contact</a>
                <?php if (isLoggedIn()): ?>
                    <a href="admin/dashboard.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Dashboard</a>
                <?php else: ?>
                    <a href="login.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Admin Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
   
    <!-- About Section -->
    <section class="pt-32 pb-16 bg-gray-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12 animate__animated animate__fadeIn">
                <h1 class="text-4xl font-bold text-primary mb-4">About <?php echo SITE_NAME; ?></h1>
                <p class="text-xl text-gray-600">Your trusted source for quality vehicles</p>
            </div>
           
            <div class="prose max-w-none mx-auto text-gray-600 leading-relaxed animate__animated animate__fadeInUp">
                <p class="mb-6"><?php echo SITE_NAME; ?> is dedicated to providing an exceptional car buying experience. With years of expertise in the automotive industry, we curate a selection of high-quality vehicles to meet every need and budget.</p>
               
                <h2 class="text-2xl font-bold text-primary mt-8 mb-4">Our Mission</h2>
                <p class="mb-6">To make car buying simple, transparent, and enjoyable by offering reliable vehicles, competitive pricing, and outstanding customer service.</p>
               
                <h2 class="text-2xl font-bold text-primary mt-8 mb-4">Why Choose Us?</h2>
                <ul class="list-disc list-inside space-y-2 mb-6">
                    <li>Wide selection of certified pre-owned and new vehicles</li>
                    <li>Competitive pricing and financing options</li>
                    <li>Expert staff with deep industry knowledge</li>
                    <li>Comprehensive vehicle history reports</li>
                    <li>Satisfaction guarantee</li>
                </ul>
               
                <p class="mb-6">Whether you're looking for a family sedan, a luxury SUV, or an eco-friendly hybrid, <?php echo SITE_NAME; ?> has you covered. Visit us today and drive home in your dream car!</p>
            </div>
        </div>
    </section>
   
    <!-- Footer -->
    <footer class="bg-primary text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-2xl font-bold mb-4">
                        <i class="fas fa-car text-accent mr-2"></i><?php echo SITE_NAME; ?>
                    </h3>
                    <p class="text-gray-300">Your trusted partner in finding quality vehicles.</p>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Quick Links</h4>
                    <ul class="space-y-2">
                        <li><a href="index.php" class="text-gray-300 hover:text-accent transition">Home</a></li>
                        <li><a href="cars.php" class="text-gray-300 hover:text-accent transition">All Cars</a></li>
                        <li><a href="about.php" class="text-gray-300 hover:text-accent transition">About</a></li>
                        <li><a href="contact.php" class="text-gray-300 hover:text-accent transition">Contact</a></li>
                    </ul>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Contact</h4>
                    <ul class="space-y-2 text-gray-300">
                        <li><i class="fas fa-phone text-accent mr-2"></i>+233202493547</li>
                        <li><i class="fas fa-envelope text-accent mr-2"></i>kabuteyautoltd@gmail.com</li>
                        <li><i class="fas fa-map-marker-alt text-accent mr-2"></i>123 Auto St, City</li>
                    </ul>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Follow Us</h4>
                    <div class="flex space-x-4">
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
            </div>
           
            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>
   
    <script>
        // Mobile menu toggle
        document.getElementById('mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('mobile-menu').classList.toggle('hidden');
        });
    </script>
</body>
</html>