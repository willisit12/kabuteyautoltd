-- Modern Car Selling Website Database Schema
-- Run this SQL to set up your database

CREATE DATABASE IF NOT EXISTS modern_cars CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE modern_cars;

-- Admins table with enhanced security
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    remember_token VARCHAR(100) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB;

-- Cars table with comprehensive fields
CREATE TABLE IF NOT EXISTS cars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    make VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    mileage INT NOT NULL,
    fuel_type ENUM('Gasoline', 'Diesel', 'Electric', 'Hybrid', 'Plug-in Hybrid') NOT NULL,
    transmission ENUM('Automatic', 'Manual', 'CVT', 'Semi-Automatic') NOT NULL,
    body_type VARCHAR(50) DEFAULT NULL,
    color VARCHAR(50) DEFAULT NULL,
    doors INT DEFAULT 4,
    description TEXT,
    `condition` ENUM('New', 'Used', 'Certified Pre-Owned') DEFAULT 'Used',
    featured BOOLEAN DEFAULT FALSE,
    `status` ENUM('available', 'sold', 'pending') DEFAULT 'available',
    views INT DEFAULT 0,
    seller_name VARCHAR(100) DEFAULT NULL,
    seller_email VARCHAR(255) DEFAULT NULL,
    seller_phone VARCHAR(20) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_make_model (make, model),
    INDEX idx_price (price),
    INDEX idx_year (year),
    INDEX idx_featured (featured),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- Car images table
CREATE TABLE IF NOT EXISTS car_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    car_id INT NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    thumbnail_path VARCHAR(255) DEFAULT NULL,
    is_primary BOOLEAN DEFAULT FALSE,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE CASCADE,
    INDEX idx_car_id (car_id),
    INDEX idx_is_primary (is_primary)
) ENGINE=InnoDB;

-- Contact inquiries table
CREATE TABLE IF NOT EXISTS inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    car_id INT DEFAULT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    message TEXT NOT NULL,
    `status` ENUM('new', 'contacted', 'closed') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (car_id) REFERENCES cars(id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_car_id (car_id)
) ENGINE=InnoDB;

-- Insert default admin (email: admin@cars.com, password: Admin123!)
INSERT INTO admins (email, password, name) VALUES 
('admin@cars.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin User');

-- Sample car data with realistic information
INSERT INTO cars (make, model, year, price, mileage, fuel_type, transmission, body_type, color, description, featured, seller_name, seller_email, seller_phone) VALUES
('Tesla', 'Model 3', 2023, 42990.00, 8500, 'Electric', 'Automatic', 'Sedan', 'Pearl White', 'Like-new Tesla Model 3 with full self-driving capability. Autopilot, premium interior, and all the latest features. One owner, meticulously maintained.', TRUE, 'Elite Motors', 'sales@elitemotors.com', '555-0100'),
('BMW', '3 Series', 2022, 38500.00, 15200, 'Gasoline', 'Automatic', 'Sedan', 'Jet Black', 'Luxury sports sedan with premium package. Navigation, leather seats, sunroof, and advanced safety features. Certified pre-owned with warranty.', TRUE, 'Elite Motors', 'sales@elitemotors.com', '555-0100'),
('Toyota', 'Camry', 2021, 26750.00, 22000, 'Hybrid', 'Automatic', 'Sedan', 'Silver Sky', 'Fuel-efficient hybrid with excellent reliability. Clean CarFax, single owner. Perfect commuter car with modern tech and safety features.', TRUE, 'Elite Motors', 'sales@elitemotors.com', '555-0100'),
('Honda', 'Civic', 2023, 24990.00, 5000, 'Gasoline', 'CVT', 'Sedan', 'Sonic Gray', 'Sporty and efficient. Brand new condition with warranty remaining. Apple CarPlay, Android Auto, adaptive cruise control, and lane keeping assist.', FALSE, 'Elite Motors', 'sales@elitemotors.com', '555-0100'),
('Ford', 'F-150', 2022, 45900.00, 18000, 'Gasoline', 'Automatic', 'Truck', 'Oxford White', 'Powerful workhorse with XLT package. Towing package, backup camera, and premium sound system. Perfect for work or weekend adventures.', FALSE, 'Elite Motors', 'sales@elitemotors.com', '555-0100'),
('Mercedes-Benz', 'E-Class', 2021, 52900.00, 12000, 'Gasoline', 'Automatic', 'Sedan', 'Obsidian Black', 'Executive sedan with every luxury option. Premium leather, Burmester sound system, advanced driver assistance, and pristine condition.', TRUE, 'Elite Motors', 'sales@elitemotors.com', '555-0100'),
('Mazda', 'CX-5', 2022, 31500.00, 14000, 'Gasoline', 'Automatic', 'SUV', 'Deep Crystal Blue', 'Stylish compact SUV with Grand Touring package. All-wheel drive, premium interior, and excellent fuel economy. Perfect family vehicle.', FALSE, 'Elite Motors', 'sales@elitemotors.com', '555-0100'),
('Audi', 'A4', 2023, 44990.00, 6000, 'Gasoline', 'Automatic', 'Sedan', 'Glacier White', 'Premium luxury sedan with Quattro all-wheel drive. Virtual cockpit, premium plus package, and immaculate condition with full warranty.', FALSE, 'Elite Motors', 'sales@elitemotors.com', '555-0100');

-- Sample car images (you'll need to add actual image files)
INSERT INTO car_images (car_id, image_path, is_primary, display_order) VALUES
(1, 'uploads/tesla-model3-1.jpg', TRUE, 1),
(1, 'uploads/tesla-model3-2.jpg', FALSE, 2),
(1, 'uploads/tesla-model3-3.jpg', FALSE, 3),
(2, 'uploads/bmw-3series-1.jpg', TRUE, 1),
(2, 'uploads/bmw-3series-2.jpg', FALSE, 2),
(3, 'uploads/toyota-camry-1.jpg', TRUE, 1),
(3, 'uploads/toyota-camry-2.jpg', FALSE, 2),
(4, 'uploads/honda-civic-1.jpg', TRUE, 1),
(5, 'uploads/ford-f150-1.jpg', TRUE, 1),
(6, 'uploads/mercedes-eclass-1.jpg', TRUE, 1),
(7, 'uploads/mazda-cx5-1.jpg', TRUE, 1),
(8, 'uploads/audi-a4-1.jpg', TRUE, 1);