<?php
// config.php - Database configuration and helper functions
// Start session with secure settings
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_only_cookies', 1);
session_start();
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'modern_cars');
// Site Configuration
define('SITE_NAME', 'Kabutey Auto Ltd');
define('SITE_URL', 'http://localhost');
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('UPLOAD_URL', 'uploads/');
// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Database Connection with error handling
function getDB() {
    static $pdo = null;
   
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            die("Database connection error. Please try again later.");
        }
    }
   
    return $pdo;
}
// CSRF Token Generation and Validation
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function validateCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
// Authentication Functions
function isLoggedIn() {
    return isset($_SESSION['admin_id']) && $_SESSION['admin_id'] > 0;
}
function requireAuth() {
    if (!isLoggedIn()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        header('Location: /login.php');
        exit;
    }
}
function getAdminInfo() {
    if (!isLoggedIn()) {
        return null;
    }
   
    $db = getDB();
    $stmt = $db->prepare("SELECT id, email, name FROM admins WHERE id = ?");
    $stmt->execute([$_SESSION['admin_id']]);
    return $stmt->fetch();
}
// Input Sanitization
function clean($input) {
    if (is_array($input)) {
        return array_map('clean', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}
// Validation Functions
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}
function validatePrice($price) {
    return is_numeric($price) && $price >= 0;
}
function validateYear($year) {
    return is_numeric($year) && $year >= 1900 && $year <= date('Y') + 1;
}
// Formatting Functions
function formatPrice($price) {
    return '$' . number_format($price, 0);
}
function formatMileage($mileage) {
    return number_format($mileage) . ' mi';
}
function formatDate($date) {
    return date('M d, Y', strtotime($date));
}
// Image Upload and Processing
function uploadCarImage($file, $carId) {
    $allowed = ['jpg', 'jpeg', 'png', 'webp'];
    $maxSize = 5 * 1024 * 1024; // 5MB
   
    // Validation
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'Upload error occurred'];
    }
   
    if ($file['size'] > $maxSize) {
        return ['success' => false, 'error' => 'File too large (max 5MB)'];
    }
   
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allowed)) {
        return ['success' => false, 'error' => 'Invalid file type'];
    }
   
    // Create upload directory if it doesn't exist
    if (!is_dir(UPLOAD_DIR)) {
        mkdir(UPLOAD_DIR, 0755, true);
    }
   
    // Generate unique filename
    $filename = 'car_' . $carId . '_' . uniqid() . '.' . $ext;
    $filepath = UPLOAD_DIR . $filename;
   
    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        return ['success' => false, 'error' => 'Failed to save file'];
    }
   
    // Create thumbnail (optional - requires GD library)
    $thumbnailPath = createThumbnail($filepath, $filename);
   
    return [
        'success' => true,
        'path' => UPLOAD_URL . $filename,
        'thumbnail' => $thumbnailPath
    ];
}
function createThumbnail($sourcePath, $filename) {
    if (!extension_loaded('gd')) {
        return null;
    }
   
    $thumbWidth = 400;
    $thumbHeight = 300;
   
    // Get image info
    $imageInfo = getimagesize($sourcePath);
    if (!$imageInfo) {
        return null;
    }
   
    list($width, $height, $type) = $imageInfo;
   
    // Create image resource based on type
    switch ($type) {
        case IMAGETYPE_JPEG:
            $source = imagecreatefromjpeg($sourcePath);
            break;
        case IMAGETYPE_PNG:
            $source = imagecreatefrompng($sourcePath);
            break;
        case IMAGETYPE_WEBP:
            $source = imagecreatefromwebp($sourcePath);
            break;
        default:
            return null;
    }
   
    // Calculate dimensions
    $ratio = min($thumbWidth / $width, $thumbHeight / $height);
    $newWidth = (int)($width * $ratio);
    $newHeight = (int)($height * $ratio);
   
    // Create thumbnail
    $thumb = imagecreatetruecolor($newWidth, $newHeight);
    imagecopyresampled($thumb, $source, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
   
    // Save thumbnail
    $thumbFilename = 'thumb_' . $filename;
    $thumbPath = UPLOAD_DIR . $thumbFilename;
   
    switch ($type) {
        case IMAGETYPE_JPEG:
            imagejpeg($thumb, $thumbPath, 85);
            break;
        case IMAGETYPE_PNG:
            imagepng($thumb, $thumbPath, 8);
            break;
        case IMAGETYPE_WEBP:
            imagewebp($thumb, $thumbPath, 85);
            break;
    }
   
    imagedestroy($source);
    imagedestroy($thumb);
   
    return UPLOAD_URL . $thumbFilename;
}
// Get car makes for filters
function getCarMakes() {
    $db = getDB();
    $stmt = $db->query("SELECT DISTINCT make FROM cars ORDER BY make");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}
// Search and filter cars
function searchCars($filters = [], $limit = 12, $offset = 0) {
    $db = getDB();
   
    $sql = "SELECT c.*,
            (SELECT image_path FROM car_images WHERE car_id = c.id AND is_primary = 1 LIMIT 1) as primary_image,
            (SELECT COUNT(*) FROM car_images WHERE car_id = c.id) as image_count
            FROM cars c
            WHERE c.status = 'available'";
   
    $params = [];
   
    if (!empty($filters['make'])) {
        $sql .= " AND c.make = ?";
        $params[] = $filters['make'];
    }
   
    if (!empty($filters['model'])) {
        $sql .= " AND c.model LIKE ?";
        $params[] = '%' . $filters['model'] . '%';
    }
   
    if (!empty($filters['year'])) {
        $sql .= " AND c.year = ?";
        $params[] = $filters['year'];
    }
   
    if (!empty($filters['min_price'])) {
        $sql .= " AND c.price >= ?";
        $params[] = $filters['min_price'];
    }
   
    if (!empty($filters['max_price'])) {
        $sql .= " AND c.price <= ?";
        $params[] = $filters['max_price'];
    }
   
    if (!empty($filters['fuel_type'])) {
        $sql .= " AND c.fuel_type = ?";
        $params[] = $filters['fuel_type'];
    }
   
    if (!empty($filters['min_mileage'])) {
        $sql .= " AND c.mileage >= ?";
        $params[] = $filters['min_mileage'];
    }
   
    if (!empty($filters['max_mileage'])) {
        $sql .= " AND c.mileage <= ?";
        $params[] = $filters['max_mileage'];
    }
   
    $sql .= " ORDER BY c.featured DESC, c.created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
   
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
   
    return $stmt->fetchAll();
}
// Get featured cars for homepage carousel
function getFeaturedCars($limit = 3) {
    $db = getDB();
    $stmt = $db->prepare("
        SELECT c.*,
        (SELECT image_path FROM car_images WHERE car_id = c.id AND is_primary = 1 LIMIT 1) as primary_image
        FROM cars c
        WHERE c.featured = 1 AND c.status = 'available'
        ORDER BY c.created_at DESC
        LIMIT ?
    ");
    $stmt->execute([$limit]);
    return $stmt->fetchAll();
}
// Get single car with all images
function getCarById($id) {
    $db = getDB();
   
    // Get car details
    $stmt = $db->prepare("SELECT * FROM cars WHERE id = ?");
    $stmt->execute([$id]);
    $car = $stmt->fetch();
   
    if (!$car) {
        return null;
    }
   
    // Get all images
    $stmt = $db->prepare("SELECT * FROM car_images WHERE car_id = ? ORDER BY is_primary DESC, display_order ASC");
    $stmt->execute([$id]);
    $car['images'] = $stmt->fetchAll();
   
    // Increment view count
    $stmt = $db->prepare("UPDATE cars SET views = views + 1 WHERE id = ?");
    $stmt->execute([$id]);
   
    return $car;
}

// Get recommended cars based on current car
function getRecommendedCars($currentCarId, $limit = 6) {
    $db = getDB();
    
    // Get current car details
    $stmt = $db->prepare("SELECT make, price FROM cars WHERE id = ?");
    $stmt->execute([$currentCarId]);
    $currentCar = $stmt->fetch();
    
    if (!$currentCar) {
        return [];
    }
    
    // Calculate price range for similar cars (within 20%)
    $priceRange = $currentCar['price'] * 0.2;
    $minPrice = $currentCar['price'] - $priceRange;
    $maxPrice = $currentCar['price'] + $priceRange;
    
    // Get recommended cars (same make or similar price)
    $stmt = $db->prepare("
        SELECT c.*,
        (SELECT image_path FROM car_images WHERE car_id = c.id AND is_primary = 1 LIMIT 1) as primary_image
        FROM cars c
        WHERE c.id != ? 
        AND c.status = 'available'
        AND (c.make = ? OR (c.price >= ? AND c.price <= ?))
        ORDER BY 
            CASE WHEN c.make = ? THEN 0 ELSE 1 END,
            ABS(c.price - ?) ASC,
            c.created_at DESC
        LIMIT ?
    ");
    
    $stmt->execute([
        $currentCarId,
        $currentCar['make'],
        $minPrice,
        $maxPrice,
        $currentCar['make'],
        $currentCar['price'],
        $limit
    ]);
    
    return $stmt->fetchAll();
}
// Redirect helper
function redirect($url, $statusCode = 302) {
    header('Location: ' . $url, true, $statusCode);
    exit;
}
// Flash message functions
function setFlash($key, $message) {
    $_SESSION['flash'][$key] = $message;
}
function getFlash($key) {
    if (isset($_SESSION['flash'][$key])) {
        $message = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $message;
    }
    return null;
}
// JSON response helper
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
// Check if user is logged in as admin
function isAdmin() {
    return isset($_SESSION['admin_id']) && $_SESSION['admin_id'] > 0;
}
?>