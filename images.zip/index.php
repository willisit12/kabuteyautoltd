<?php
// index.php - Modern homepage with Tailwind, Swiper, and animations
require_once 'config.php';
// Get featured cars for hero carousel
$featuredCars = getFeaturedCars(4);
// Get latest cars
$filters = [
    'make' => $_GET['make'] ?? '',
    'model' => $_GET['model'] ?? '',
    'year' => $_GET['year'] ?? '',
    'min_price' => $_GET['min_price'] ?? '',
    'max_price' => $_GET['max_price'] ?? '',
    'fuel_type' => $_GET['fuel_type'] ?? ''
];
$latestCars = searchCars($filters, 12);
$makes = getCarMakes();
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - Find Your Perfect Car</title>

    <!-- Basic Meta Tags -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="Kabutey Auto Ltd is a trusted vehicle importation company in Ghana, specializing in brand new and quality used cars shipped from the USA, China, Korea, and Japan with reliable delivery and competitive pricing.">
    <meta name="keywords" content="car importation Ghana, vehicle shipping to Ghana, used cars Ghana, brand new cars Ghana, import cars from USA to Ghana, import cars from Japan to Ghana, import cars from Korea to Ghana, import cars from China to Ghana">
    <meta name="author" content="Kabutey Auto Ltd">
    <meta name="robots" content="index, follow">

    <!-- Canonical URL -->
    <link rel="canonical" href="https://www.kabuteyauto.com/">

    <!-- Open Graph / Facebook / LinkedIn -->
    <meta property="og:type" content="website">
    <meta property="og:title" content="Kabutey Auto Ltd | Reliable Car Importation to Ghana">
    <meta property="og:description" content="We import brand new and second-hand vehicles from the USA, China, Korea, and Japan to Ghana. Kabutey Auto Ltd delivers trusted sourcing, secure shipping, and transparent pricing.">
    <meta property="og:url" content="https://www.kabuteyauto.com/">
    <meta property="og:site_name" content="Kabutey Auto Ltd">
    <meta property="og:image" content="https://www.kabuteyauto.com/images/logo-main.png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="Kabutey Auto Ltd car importation and shipping services to Ghana">

    <!-- Twitter / X -->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Kabutey Auto Ltd | Car Importation Experts in Ghana">
    <meta name="twitter:description" content="Import brand new and quality used cars from the USA, China, Korea, and Japan to Ghana with Kabutey Auto Ltd. Trusted service and dependable delivery.">
    <meta name="twitter:image" content="https://www.kabuteyauto.com/images/logo-main.png">
    <meta name="twitter:site" content="@KabuteyAuto">
    <meta name="twitter:creator" content="@KabuteyAuto">

    <!-- Theme / Browser -->
    <meta name="theme-color" content="#0d1b2a">
    <meta name="apple-mobile-web-app-title" content="Kabutey Auto Ltd">
    <meta name="application-name" content="Kabutey Auto Ltd">

    <!-- Favicon -->
    <link rel="icon" href="images/car.png">
    <link rel="apple-touch-icon" sizes="180x180" href="images/car.png">

   
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e293b',
                        secondary: '#334155',
                        accent: '#ea580c',
                        'accent-teal': '#14b8a6'
                    },
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
   
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
   
    <!-- Animate.css -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
   
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
   
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
   
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
       
        /* Parallax hero section */
        .parallax-hero {
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            position: relative;
            min-height: 700px;
            overflow: hidden;
        }
        
        .parallax-hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-image: 
                radial-gradient(circle at 20% 50%, rgba(234, 88, 12, 0.1) 0%, transparent 50%),
                radial-gradient(circle at 80% 80%, rgba(20, 184, 166, 0.1) 0%, transparent 50%);
            pointer-events: none;
        }
        
        .hero-content {
            position: relative;
            z-index: 1;
        }
       
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 10px;
        }
       
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
       
        ::-webkit-scrollbar-thumb {
            background: #ea580c;
            border-radius: 5px;
        }
       
        ::-webkit-scrollbar-thumb:hover {
            background: #d84a07;
        }
       
        /* Swiper customization */
        .swiper-button-next, .swiper-button-prev {
            color: white !important;
            background: rgba(234, 88, 12, 0.9) !important;
            width: 50px !important;
            height: 50px !important;
            border-radius: 50%;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(234, 88, 12, 0.3);
        }
        
        .swiper-button-next:hover, .swiper-button-prev:hover {
            background: #ea580c !important;
            transform: scale(1.1);
            box-shadow: 0 6px 20px rgba(234, 88, 12, 0.5);
        }
       
        .swiper-button-next:after, .swiper-button-prev:after {
            font-size: 20px !important;
        }
       
        .swiper-pagination-bullet {
            background: rgba(255, 255, 255, 0.5) !important;
            transition: all 0.3s ease;
        }
        
        .swiper-pagination-bullet-active {
            background: #ea580c !important;
            width: 30px !important;
            border-radius: 10px !important;
        }
        
        /* Modern card hover effects */
        .car-card {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(0, 0, 0, 0.05);
            background: white;
        }
        
        .car-card:hover {
            transform: translateY(-12px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
            border-color: rgba(234, 88, 12, 0.3);
        }
        
        .car-card:hover .car-image {
            transform: scale(1.08);
        }
        
        .car-image {
            overflow: hidden;
            transition: transform 0.4s ease;
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        }
        
        /* Badge styles */
        .badge {
            background: linear-gradient(135deg, #ea580c, #d84a07);
            box-shadow: 0 4px 15px rgba(234, 88, 12, 0.3);
        }
        
        /* Button styles */
        .btn-primary {
            background: linear-gradient(135deg, #ea580c, #d84a07);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .btn-primary::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.2);
            transition: left 0.3s ease;
            z-index: 1;
        }
        
        .btn-primary:hover::before {
            left: 100%;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(234, 88, 12, 0.4);
        }
        
        .btn-secondary {
            background: linear-gradient(135deg, #1e293b, #334155);
            transition: all 0.3s ease;
        }
        
        .btn-secondary:hover {
            background: linear-gradient(135deg, #0f172a, #1e293b);
            transform: translateY(-2px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        }
        
        /* Search section styling */
        .search-section {
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        }
        
        .search-form {
            background: white;
            border: 1px solid rgba(0, 0, 0, 0.05);
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.08);
        }
        
        .form-input {
            transition: all 0.3s ease;
            background: #f8fafc;
            border: 2px solid transparent;
        }
        
        .form-input:focus {
            background: white;
            border-color: #ea580c;
            box-shadow: 0 0 0 3px rgba(234, 88, 12, 0.1);
        }
        
        /* Section titles */
        .section-title {
            position: relative;
            display: inline-block;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #ea580c, #d84a07);
            border-radius: 2px;
        }
        
        /* Featured carousel card */
        .featured-card {
            border-radius: 24px;
            overflow: hidden;
            transition: all 0.3s ease;
        }
        
        .featured-card:hover {
            transform: scale(1.02);
        }
        
        .featured-card-content {
            background: linear-gradient(to top, rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.4), transparent);
        }
        
        /* Stats counters */
        .stat-box {
            text-align: center;
            padding: 24px;
            border-radius: 16px;
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            transition: all 0.3s ease;
            border: 1px solid rgba(234, 88, 12, 0.1);
        }
        
        .stat-box:hover {
            border-color: #ea580c;
            box-shadow: 0 10px 30px rgba(234, 88, 12, 0.15);
        }
        
        .stat-number {
            background: linear-gradient(135deg, #ea580c, #d84a07);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
    </style>
</head>
<body class="bg-gray-50">
   
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <div class="flex items-center">
                    <a href="index.php">
                        <img src="images/logo-main.png" alt="<?php echo SITE_NAME; ?>" class="h-16 object-contain">
                    </a>
                </div>
               
                <div class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-accent transition font-medium">Home</a>
                    <a href="cars.php" class="text-gray-700 hover:text-accent transition font-medium">All Cars</a>
                    <a href="about.php" class="text-gray-700 hover:text-accent transition font-medium">About</a>
                    <a href="contact.php" class="text-gray-700 hover:text-accent transition font-medium">Contact</a>
                    <?php if (isLoggedIn()): ?>
                        <a href="admin/dashboard.php" class="bg-accent text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition">
                            <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-700 hover:text-accent transition font-medium">
                            <i class="fas fa-user mr-1"></i>Admin
                        </a>
                    <?php endif; ?>
                </div>
               
                <!-- Mobile menu button -->
                <button id="mobile-menu-btn" class="md:hidden text-gray-700 hover:text-accent">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
       
        <!-- Mobile menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-white border-t">
            <div class="px-4 pt-2 pb-4 space-y-2">
                <a href="index.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Home</a>
                <a href="cars.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">All Cars</a>
                <a href="about.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">About</a>
                <a href="contact.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Contact</a>
                <?php if (isLoggedIn()): ?>
                    <a href="admin/dashboard.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Dashboard</a>
                <?php else: ?>
                    <a href="login.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Admin Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
   
    <!-- Hero Section with Parallax -->
    <section class="parallax-hero flex items-center justify-center pt-20">
        <div class="hero-content text-center text-white px-4 animate__animated animate__fadeIn max-w-4xl">
            <div class="mb-6">
                <span class="inline-block px-4 py-2 bg-gradient-to-r from-accent to-orange-700 rounded-full text-sm font-semibold mb-6">
                    ✨ Find Your Perfect Vehicle Today
                </span>
            </div>
            <h1 class="text-5xl md:text-7xl font-bold mb-6 animate__animated animate__fadeInDown leading-tight">
                Discover Your <span class="bg-gradient-to-r from-accent to-orange-700 bg-clip-text text-transparent">Dream Car</span>
            </h1>
            <p class="text-lg md:text-2xl mb-10 animate__animated animate__fadeInUp text-gray-300">
                Explore our premium collection of quality vehicles at unbeatable prices
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center animate__animated animate__fadeInUp animate__delay-1s">
                <a href="#search" class="btn-primary inline-flex items-center justify-center px-8 py-4 rounded-lg text-lg font-semibold text-white">
                    <i class="fas fa-search mr-2"></i>Start Browsing
                </a>
                <a href="cars.php" class="inline-flex items-center justify-center px-8 py-4 rounded-lg text-lg font-semibold text-white border-2 border-white hover:bg-white hover:text-primary transition">
                    <i class="fas fa-car mr-2"></i>View All Cars
                </a>
            </div>
        </div>
    </section>
   
    <!-- Featured Cars Carousel -->
    <?php if (count($featuredCars) > 0): ?>
    <section class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16 animate__animated animate__fadeInUp">
                <h2 class="text-4xl md:text-5xl font-bold text-primary mb-4 section-title">Featured Vehicles</h2>
                <p class="text-gray-600 text-lg mt-8">Discover our handpicked collection of premium vehicles</p>
            </div>
           
            <div class="swiper featuredSwiper animate__animated animate__fadeInUp">
                <div class="swiper-wrapper">
                    <?php foreach ($featuredCars as $car):
                        $image = $car['primary_image'] ?? 'https://via.placeholder.com/800x600?text=No+Image';
                    ?>
                    <div class="swiper-slide">
                        <div class="featured-card relative overflow-hidden">
                            <div class="car-image h-[500px]">
                                <img src="<?php echo $image; ?>"
                                     alt="<?php echo clean($car['make'] . ' ' . $car['model']); ?>"
                                     class="w-full h-full object-cover">
                            </div>
                            <div class="featured-card-content absolute inset-0"></div>
                            <div class="absolute bottom-0 left-0 right-0 p-8 text-white z-10">
                                <h3 class="text-3xl font-bold mb-2">
                                    <?php echo clean($car['year'] . ' ' . $car['make'] . ' ' . $car['model']); ?>
                                </h3>
                                <p class="text-gray-300 mb-6">Premium quality, exceptional value</p>
                                <div class="flex items-center justify-between">
                                    <span class="text-3xl font-bold text-accent"><?php echo formatPrice($car['price']); ?></span>
                                    <a href="car-details.php?id=<?php echo $car['id']; ?>"
                                       class="btn-primary px-6 py-3 rounded-lg font-semibold">
                                        View Details <i class="fas fa-arrow-right ml-2"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
                <div class="swiper-pagination mt-8"></div>
            </div>
        </div>
    </section>
    <?php endif; ?>
   
    <!-- Search Section -->
    <section id="search" class="search-section py-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="search-form rounded-3xl p-10 animate__animated animate__fadeInUp">
                <div class="mb-8">
                    <h3 class="text-3xl font-bold text-primary mb-2 section-title">
                        <i class="fas fa-search text-accent mr-2"></i>Find Your Perfect Vehicle
                    </h3>
                    <p class="text-gray-600 mt-6">Search through our extensive inventory with advanced filters</p>
                </div>
               
                <form method="GET" action="index.php" class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-3">Make</label>
                            <select name="make" class="form-input w-full px-4 py-3 rounded-xl border-2 border-transparent">
                                <option value="">All Makes</option>
                                <?php foreach ($makes as $make): ?>
                                    <option value="<?php echo $make; ?>" <?php echo ($filters['make'] === $make) ? 'selected' : ''; ?>>
                                        <?php echo $make; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                       
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-3">Model</label>
                            <input type="text" name="model" value="<?php echo clean($filters['model']); ?>"
                                   placeholder="e.g., Camry"
                                   class="form-input w-full px-4 py-3 rounded-xl border-2 border-transparent">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-3">Year</label>
                            <input type="number" name="year" value="<?php echo clean($filters['year']); ?>"
                                   placeholder="e.g., 2022" min="1900" max="<?php echo date('Y') + 1; ?>"
                                   class="form-input w-full px-4 py-3 rounded-xl border-2 border-transparent">
                        </div>
                    </div>
                   
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-3">Min Price</label>
                            <input type="number" name="min_price" value="<?php echo clean($filters['min_price']); ?>"
                                   placeholder="$0" step="1000"
                                   class="form-input w-full px-4 py-3 rounded-xl border-2 border-transparent">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-3">Max Price</label>
                            <input type="number" name="max_price" value="<?php echo clean($filters['max_price']); ?>"
                                   placeholder="Any" step="1000"
                                   class="form-input w-full px-4 py-3 rounded-xl border-2 border-transparent">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-3">Fuel Type</label>
                            <select name="fuel_type" class="form-input w-full px-4 py-3 rounded-xl border-2 border-transparent">
                                <option value="">All Types</option>
                                <option value="Gasoline" <?php echo ($filters['fuel_type'] === 'Gasoline') ? 'selected' : ''; ?>>Gasoline</option>
                                <option value="Diesel" <?php echo ($filters['fuel_type'] === 'Diesel') ? 'selected' : ''; ?>>Diesel</option>
                                <option value="Electric" <?php echo ($filters['fuel_type'] === 'Electric') ? 'selected' : ''; ?>>Electric</option>
                                <option value="Hybrid" <?php echo ($filters['fuel_type'] === 'Hybrid') ? 'selected' : ''; ?>>Hybrid</option>
                            </select>
                        </div>
                    </div>
                   
                    <div class="flex flex-col sm:flex-row gap-4 pt-6">
                        <button type="submit" class="btn-primary flex-1 px-8 py-4 rounded-xl font-semibold text-white transition">
                            <i class="fas fa-search mr-2"></i>Search Vehicles
                        </button>
                        <a href="index.php" class="btn-secondary px-8 py-4 rounded-xl font-semibold text-white transition text-center">
                            <i class="fas fa-redo mr-2"></i>Reset Filters
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </section>
   
    <!-- Latest Cars -->
    <section class="py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16 animate__animated animate__fadeInUp">
                <h2 class="text-4xl md:text-5xl font-bold text-primary mb-4 section-title">Latest Arrivals</h2>
                <p class="text-gray-600 text-lg mt-8">Explore our newest additions to the inventory</p>
            </div>
           
            <?php if (count($latestCars) > 0): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach ($latestCars as $car):
                    $image = $car['primary_image'] ?? 'https://via.placeholder.com/400x300?text=No+Image';
                ?>
                <div class="car-card bg-white rounded-3xl overflow-hidden shadow-lg animate__animated animate__fadeInUp border border-gray-100">
                    <div class="relative car-image h-64 overflow-hidden bg-gray-200">
                        <img src="<?php echo $image; ?>"
                             alt="<?php echo clean($car['make'] . ' ' . $car['model']); ?>"
                             class="w-full h-full object-cover"
                             loading="lazy">
                        <?php if ($car['featured']): ?>
                        <div class="absolute top-4 left-4 z-10">
                            <span class="badge inline-flex items-center px-4 py-2 rounded-full text-xs font-bold text-white uppercase tracking-wide">
                                <i class="fas fa-star mr-2"></i>Featured
                            </span>
                        </div>
                        <?php endif; ?>
                        <div class="absolute top-4 right-4">
                            <div class="bg-white bg-opacity-95 backdrop-blur px-3 py-2 rounded-full text-xs font-semibold text-primary">
                                <?php echo $car['image_count'] ?? 0; ?> Photos
                            </div>
                        </div>
                    </div>
                   
                    <div class="p-7">
                        <div class="mb-3">
                            <h3 class="text-xl font-bold text-primary leading-tight">
                                <?php echo clean($car['year']); ?> <?php echo clean($car['make'] . ' ' . $car['model']); ?>
                            </h3>
                            <!-- <p class="text-xl font-semibold text-gray-700 mt-1">
                                <?php echo clean($car['make'] . ' ' . $car['model']); ?>
                            </p> -->
                        </div>
                       
                        <div class="mb-6">
                            <span class="text-4xl font-bold bg-gradient-to-r from-accent to-orange-700 bg-clip-text text-transparent">
                                <?php echo formatPrice($car['price']); ?>
                            </span>
                        </div>
                       
                        <div class="space-y-3 mb-7 pb-7 border-b border-gray-200">
                            <div class="flex items-center justify-between text-sm">
                                <div class="flex items-center text-gray-600">
                                    <span class="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-accent bg-opacity-10 text-accent mr-3">
                                        <i class="fas fa-tachometer-alt text-xs"></i>
                                    </span>
                                    <span class="font-medium"><?php echo formatMileage($car['mileage']); ?></span>
                                </div>
                            </div>
                            <div class="flex items-center justify-between text-sm">
                                <div class="flex items-center text-gray-600">
                                    <span class="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-accent bg-opacity-10 text-accent mr-3">
                                        <i class="fas fa-gas-pump text-xs"></i>
                                    </span>
                                    <span class="font-medium"><?php echo $car['fuel_type']; ?></span>
                                </div>
                            </div>
                            <div class="flex items-center justify-between text-sm">
                                <div class="flex items-center text-gray-600">
                                    <span class="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-accent bg-opacity-10 text-accent mr-3">
                                        <i class="fas fa-cog text-xs"></i>
                                    </span>
                                    <span class="font-medium"><?php echo $car['transmission']; ?></span>
                                </div>
                            </div>
                        </div>
                       
                        <a href="car-details.php?id=<?php echo $car['id']; ?>"
                           class="block w-full bg-primary text-white text-center py-3.5 rounded-xl font-bold transition-all duration-300 hover:shadow-lg hover:scale-105 active:scale-95">
                            View Details <i class="fas fa-arrow-right ml-2"></i>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-16">
                <i class="fas fa-car-side text-6xl text-gray-300 mb-4"></i>
                <p class="text-xl text-gray-500 mb-6">No cars found matching your criteria</p>
                <a href="index.php" class="inline-block px-6 py-3 bg-accent text-white rounded-lg font-semibold hover:bg-orange-700 transition">
                    Clear Filters
                </a>
            </div>
            <?php endif; ?>
        </div>
    </section>
   
    <!-- Footer -->
    <footer class="bg-gradient-to-br from-primary via-secondary to-primary text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
                <div>
                    <h3 class="text-2xl font-bold mb-4 flex items-center">
                        <img src="images/logo-main.png" alt="<?php echo SITE_NAME; ?>" class="h-10 object-contain mr-2">
                    </h3>
                    <p class="text-gray-400 leading-relaxed">Your trusted partner in finding quality vehicles and making your automotive dreams a reality.</p>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-6">Quick Links</h4>
                    <ul class="space-y-3">
                        <li><a href="index.php" class="text-gray-400 hover:text-accent transition flex items-center"><i class="fas fa-chevron-right mr-2 text-sm"></i>Home</a></li>
                        <li><a href="cars.php" class="text-gray-400 hover:text-accent transition flex items-center"><i class="fas fa-chevron-right mr-2 text-sm"></i>All Cars</a></li>
                        <li><a href="about.php" class="text-gray-400 hover:text-accent transition flex items-center"><i class="fas fa-chevron-right mr-2 text-sm"></i>About Us</a></li>
                        <li><a href="contact.php" class="text-gray-400 hover:text-accent transition flex items-center"><i class="fas fa-chevron-right mr-2 text-sm"></i>Contact</a></li>
                    </ul>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-6">Contact Info</h4>
                    <ul class="space-y-3 text-gray-400">
                        <li class="flex items-start"><i class="fas fa-phone text-accent mr-3 mt-1"></i><span>+233202493547</span></li>
                        <li class="flex items-start"><i class="fas fa-envelope text-accent mr-3 mt-1"></i><span>kabuteyautoltd@gmail.com</span></li>
                        <li class="flex items-start"><i class="fas fa-map-marker-alt text-accent mr-3 mt-1"></i><span>Accra, Ghana</span></li>
                    </ul>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-6">Follow Us</h4>
                    <div class="flex space-x-4">
                        <a href="#" class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-accent bg-opacity-20 text-accent hover:bg-opacity-30 transition">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-accent bg-opacity-20 text-accent hover:bg-opacity-30 transition">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-accent bg-opacity-20 text-accent hover:bg-opacity-30 transition">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-accent bg-opacity-20 text-accent hover:bg-opacity-30 transition">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </div>
                </div>
            </div>
           
            <div class="border-t border-gray-700 pt-8 mt-8">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div class="text-center md:text-left">
                        <p class="text-sm text-gray-400">✓ Certified Vehicles</p>
                    </div>
                    <div class="text-center">
                        <p class="text-sm text-gray-400">✓ 30-Day Money-Back Guarantee</p>
                    </div>
                    <div class="text-center md:text-right">
                        <p class="text-sm text-gray-400">✓ 24/7 Customer Support</p>
                    </div>
                </div>
                <div class="text-center text-gray-400 border-t border-gray-700 pt-8">
                    <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved. | <a href="#" class="hover:text-accent transition">Privacy Policy</a> | <a href="#" class="hover:text-accent transition">Terms of Service</a></p>
                </div>
            </div>
        </div>
    </footer>
   
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
   
    <script>
        // Mobile menu toggle
        document.getElementById('mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('mobile-menu').classList.toggle('hidden');
        });
       
        // Featured cars Swiper
        const swiper = new Swiper('.featuredSwiper', {
            loop: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
            effect: 'fade',
            fadeEffect: {
                crossFade: true
            }
        });
       
        // Scroll to top button
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                document.body.classList.add('show-scroll-top');
            } else {
                document.body.classList.remove('show-scroll-top');
            }
        });
    </script>
</body>
</html>