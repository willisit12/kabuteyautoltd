<?php
// login.php - Clean, modern admin login page
require_once 'config.php';

// Handle login submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    if (!validateCSRFToken($csrf_token)) {
        setFlash('error', 'Invalid security token');
        redirect('login.php');
    }

    $email = clean($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);

    if (!validateEmail($email)) {
        setFlash('error', 'Invalid email format');
        redirect('login.php');
    }

    if (empty($password)) {
        setFlash('error', 'Password is required');
        redirect('login.php');
    }

    $db = getDB();
    $stmt = $db->prepare("SELECT id, name, email, password_hash FROM admins WHERE email = ?");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password_hash'])) {
        $_SESSION['admin_id'] = $admin['id'];
        setFlash('success', 'Welcome back, ' . $admin['name']);

        $redirect = $_SESSION['redirect_after_login'] ?? './admin/dashboard.php';
        unset($_SESSION['redirect_after_login']);
        redirect($redirect);
    } else {
        setFlash('error', 'Invalid email or password');
        redirect('login.php');
    }
}

// For forgot password, simple placeholder
if (isset($_GET['forgot'])) {
    setFlash('info', 'Password reset link sent to your email (placeholder functionality)');
    redirect('login.php');
}

$error = getFlash('error');
$success = getFlash('success');
$info = getFlash('info');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - <?php echo SITE_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e293b',
                        secondary: '#334155',
                        accent: '#ea580c',
                    },
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
    <div class="w-full max-w-md bg-white rounded-2xl shadow-xl p-8 animate__animated animate__fadeIn">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-primary"><i class="fas fa-lock mr-2 text-accent"></i>Admin Login</h1>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded-lg mb-6 flex items-center">
                <i class="fas fa-exclamation-circle mr-2"></i><?php echo $error; ?>
            </div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded-lg mb-6 flex items-center">
                <i class="fas fa-check-circle mr-2"></i><?php echo $success; ?>
            </div>
        <?php endif; ?>
        <?php if ($info): ?>
            <div class="bg-blue-100 text-blue-700 p-4 rounded-lg mb-6 flex items-center">
                <i class="fas fa-info-circle mr-2"></i><?php echo $info; ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                <input type="email" name="email" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition" placeholder="admin@example.com">
            </div>
            
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Password</label>
                <input type="password" name="password" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition" placeholder="********">
            </div>
            
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <input type="checkbox" name="remember" id="remember" class="h-4 w-4 text-accent focus:ring-accent border-gray-300 rounded">
                    <label for="remember" class="ml-2 text-sm text-gray-600">Remember me</label>
                </div>
                <a href="login.php?forgot=1" class="text-sm text-accent hover:underline">Forgot password?</a>
            </div>
            
            <button type="submit" class="w-full bg-accent text-white py-3 rounded-lg font-semibold hover:bg-orange-700 transition">Login</button>
        </form>
        
        <p class="text-center mt-6 text-sm text-gray-600">
            <a href="index.php" class="text-accent hover:underline">Back to Home</a>
        </p>
    </div>
</body>
</html>