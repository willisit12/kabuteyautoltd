<?php
// cars.php - All cars listing page, similar to index but potentially with pagination
require_once 'config.php';

$page = max(1, intval($_GET['page'] ?? 1));
$limit = 12;
$offset = ($page - 1) * $limit;

$filters = [
    'make' => clean($_GET['make'] ?? ''),
    'model' => clean($_GET['model'] ?? ''),
    'year' => clean($_GET['year'] ?? ''),
    'min_price' => clean($_GET['min_price'] ?? ''),
    'max_price' => clean($_GET['max_price'] ?? ''),
    'fuel_type' => clean($_GET['fuel_type'] ?? ''),
    'min_mileage' => clean($_GET['min_mileage'] ?? ''),
    'max_mileage' => clean($_GET['max_mileage'] ?? ''),
];

$cars = searchCars($filters, $limit, $offset);
// For total, we can count without limit
$totalSql = "SELECT COUNT(*) FROM cars c WHERE c.status = 'available'";
$totalParams = [];
// Add same filter conditions as in searchCars
if (!empty($filters['make'])) {
    $totalSql .= " AND c.make = ?";
    $totalParams[] = $filters['make'];
}
// ... add all other filters similarly
$db = getDB();
$stmt = $db->prepare($totalSql);
$stmt->execute($totalParams);
$totalCars = $stmt->fetchColumn();
$totalPages = ceil($totalCars / $limit);

$makes = getCarMakes();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Cars - <?php echo SITE_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e293b',
                        secondary: '#334155',
                        accent: '#ea580c',
                    },
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <div class="flex items-center">
                    <a href="index.php">
                        <img src="images/logo-main.png" alt="<?php echo SITE_NAME; ?>" class="h-16 object-contain">
                    </a>
                </div>
               
                <div class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-accent transition font-medium">Home</a>
                    <a href="cars.php" class="text-gray-700 hover:text-accent transition font-medium">All Cars</a>
                    <a href="about.php" class="text-gray-700 hover:text-accent transition font-medium">About</a>
                    <a href="contact.php" class="text-gray-700 hover:text-accent transition font-medium">Contact</a>
                    <?php if (isLoggedIn()): ?>
                        <a href="admin/dashboard.php" class="bg-accent text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition">
                            <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-700 hover:text-accent transition font-medium">
                            <i class="fas fa-user mr-1"></i>Admin
                        </a>
                    <?php endif; ?>
                </div>
               
                <!-- Mobile menu button -->
                <button id="mobile-menu-btn" class="md:hidden text-gray-700 hover:text-accent">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
       
        <!-- Mobile menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-white border-t">
            <div class="px-4 pt-2 pb-4 space-y-2">
                <a href="index.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Home</a>
                <a href="cars.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">All Cars</a>
                <a href="about.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">About</a>
                <a href="contact.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Contact</a>
                <?php if (isLoggedIn()): ?>
                    <a href="admin/dashboard.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Dashboard</a>
                <?php else: ?>
                    <a href="login.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Admin Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
   
    <!-- Main Content -->
    <section class="pt-32 pb-16 bg-gray-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h1 class="text-4xl font-bold text-primary">All Cars</h1>
                <p class="text-gray-600 text-lg mt-2">Browse our complete inventory</p>
            </div>
           
            <div class="bg-white rounded-2xl shadow-xl p-8 mb-12 animate__animated animate__fadeInUp">
                <h3 class="text-2xl font-bold text-primary mb-6 text-center">
                    <i class="fas fa-filter text-accent mr-2"></i>Filter Cars
                </h3>
               
                <form method="GET" action="cars.php" class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Make</label>
                            <select name="make" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                                <option value="">All Makes</option>
                                <?php foreach ($makes as $make): ?>
                                    <option value="<?php echo $make; ?>" <?php echo ($filters['make'] === $make) ? 'selected' : ''; ?>>
                                        <?php echo $make; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Model</label>
                            <input type="text" name="model" value="<?php echo clean($filters['model']); ?>"
                                   placeholder="e.g., Camry"
                                   class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Year</label>
                            <input type="number" name="year" value="<?php echo clean($filters['year']); ?>"
                                   placeholder="e.g., 2022" min="1900" max="<?php echo date('Y') + 1; ?>"
                                   class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                    </div>
                   
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Min Price</label>
                            <input type="number" name="min_price" value="<?php echo clean($filters['min_price']); ?>"
                                   placeholder="$0" step="1000"
                                   class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Max Price</label>
                            <input type="number" name="max_price" value="<?php echo clean($filters['max_price']); ?>"
                                   placeholder="Any" step="1000"
                                   class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Fuel Type</label>
                            <select name="fuel_type" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                                <option value="">All Types</option>
                                <option value="Gasoline" <?php echo ($filters['fuel_type'] === 'Gasoline') ? 'selected' : ''; ?>>Gasoline</option>
                                <option value="Diesel" <?php echo ($filters['fuel_type'] === 'Diesel') ? 'selected' : ''; ?>>Diesel</option>
                                <option value="Electric" <?php echo ($filters['fuel_type'] === 'Electric') ? 'selected' : ''; ?>>Electric</option>
                                <option value="Hybrid" <?php echo ($filters['fuel_type'] === 'Hybrid') ? 'selected' : ''; ?>>Hybrid</option>
                            </select>
                        </div>
                    </div>
                   
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Min Mileage</label>
                            <input type="number" name="min_mileage" value="<?php echo clean($filters['min_mileage']); ?>"
                                   placeholder="0 mi" step="1000"
                                   class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Max Mileage</label>
                            <input type="number" name="max_mileage" value="<?php echo clean($filters['max_mileage']); ?>"
                                   placeholder="Any" step="1000"
                                   class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                    </div>
                   
                    <div class="flex gap-4">
                        <button type="submit" class="flex-1 bg-accent text-white py-4 rounded-lg font-semibold hover:bg-orange-700 transition transform hover:scale-105">
                            <i class="fas fa-search mr-2"></i>Search Cars
                        </button>
                        <a href="cars.php" class="px-8 py-4 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300 transition">
                            <i class="fas fa-redo mr-2"></i>Reset
                        </a>
                    </div>
                </form>
            </div>
           
            <?php if (count($cars) > 0): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach ($cars as $car):
                    $image = $car['primary_image'] ?? 'https://via.placeholder.com/400x300?text=No+Image';
                ?>
                <div class="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 animate__animated animate__fadeInUp">
                    <div class="relative">
                        <img src="<?php echo $image; ?>"
                             alt="<?php echo clean($car['make'] . ' ' . $car['model']); ?>"
                             class="w-full h-64 object-cover"
                             loading="lazy">
                        <?php if ($car['featured']): ?>
                        <span class="absolute top-4 left-4 bg-accent text-white px-3 py-1 rounded-full text-sm font-semibold">
                            <i class="fas fa-star mr-1"></i>Featured
                        </span>
                        <?php endif; ?>
                    </div>
                   
                    <div class="p-6">
                        <h3 class="text-2xl font-bold text-primary mb-3">
                            <?php echo clean($car['year'] . ' ' . $car['make'] . ' ' . $car['model']); ?>
                        </h3>
                       
                        <div class="flex items-center justify-between mb-4">
                            <span class="text-3xl font-bold text-accent"><?php echo formatPrice($car['price']); ?></span>
                        </div>
                       
                        <div class="grid grid-cols-2 gap-3 mb-4 text-sm text-gray-600">
                            <div class="flex items-center">
                                <i class="fas fa-calendar text-accent mr-2"></i>
                                <?php echo $car['year']; ?>
                            </div>
                            <div class="flex items-center">
                                <i class="fas fa-tachometer-alt text-accent mr-2"></i>
                                <?php echo formatMileage($car['mileage']); ?>
                            </div>
                            <div class="flex items-center">
                                <i class="fas fa-gas-pump text-accent mr-2"></i>
                                <?php echo $car['fuel_type']; ?>
                            </div>
                            <div class="flex items-center">
                                <i class="fas fa-cog text-accent mr-2"></i>
                                <?php echo $car['transmission']; ?>
                            </div>
                        </div>
                       
                        <a href="car-details.php?id=<?php echo $car['id']; ?>"
                           class="block w-full bg-primary text-white text-center py-3 rounded-lg font-semibold hover:bg-secondary transition">
                            View Details <i class="fas fa-arrow-right ml-2"></i>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="text-center py-12">
                <i class="fas fa-car-side text-6xl text-gray-300 mb-4"></i>
                <p class="text-xl text-gray-500">No cars found matching your criteria</p>
                <a href="cars.php" class="inline-block mt-4 text-accent hover:underline">Clear filters</a>
            </div>
            <?php endif; ?>
           
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
            <div class="flex justify-center mt-12 space-x-2">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <a href="cars.php?page=<?php echo $i; ?>&<?php echo http_build_query($filters); ?>"
                   class="px-4 py-2 rounded-lg <?php echo $page == $i ? 'bg-accent text-white' : 'bg-white text-gray-700 hover:bg-gray-100 shadow'; ?> transition">
                    <?php echo $i; ?>
                </a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>
   
    <!-- Footer -->
    <footer class="bg-primary text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-2xl font-bold mb-4">
                        <i class="fas fa-car text-accent mr-2"></i><?php echo SITE_NAME; ?>
                    </h3>
                    <p class="text-gray-300">Your trusted partner in finding quality vehicles.</p>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Quick Links</h4>
                    <ul class="space-y-2">
                        <li><a href="index.php" class="text-gray-300 hover:text-accent transition">Home</a></li>
                        <li><a href="cars.php" class="text-gray-300 hover:text-accent transition">All Cars</a></li>
                        <li><a href="about.php" class="text-gray-300 hover:text-accent transition">About</a></li>
                        <li><a href="contact.php" class="text-gray-300 hover:text-accent transition">Contact</a></li>
                    </ul>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Contact</h4>
                    <ul class="space-y-2 text-gray-300">
                        <li><i class="fas fa-phone text-accent mr-2"></i>+233202493547</li>
                        <li><i class="fas fa-envelope text-accent mr-2"></i>kabuteyautoltd@gmail.com</li>
                        <li><i class="fas fa-map-marker-alt text-accent mr-2"></i>123 Auto St, City</li>
                    </ul>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Follow Us</h4>
                    <div class="flex space-x-4">
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
            </div>
           
            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>
   
    <script>
        // Mobile menu toggle
        document.getElementById('mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('mobile-menu').classList.toggle('hidden');
        });
    </script>
</body>
</html>