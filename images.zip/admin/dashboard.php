<?php
// admin/dashboard.php - Admin dashboard to manage cars
require_once '../config.php';
requireAuth();

$admin = getAdminInfo();

$db = getDB();
$stmt = $db->prepare("SELECT * FROM cars ORDER BY created_at DESC");
$stmt->execute();
$cars = $stmt->fetchAll();

$success = getFlash('success');
$error = getFlash('error');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo SITE_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e293b',
                        secondary: '#334155',
                        accent: '#ea580c',
                    },
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Admin Navigation -->
    <nav class="bg-primary text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <a href="../index.php" class="text-2xl font-bold">
                    <i class="fas fa-car text-accent mr-2"></i><?php echo SITE_NAME; ?> Admin
                </a>
                <div class="flex items-center space-x-6">
                    <span class="hidden md:block">Welcome, <?php echo clean($admin['name']); ?></span>
                    <a href="add-car.php" class="bg-accent px-4 py-2 rounded-lg hover:bg-orange-700 transition">
                        <i class="fas fa-plus mr-2"></i>Add Car
                    </a>
                    <a href="logout.php" class="text-white hover:text-gray-300 transition">
                        <i class="fas fa-sign-out-alt mr-2"></i>Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>
   
    <!-- Dashboard Content -->
    <section class="pt-24 pb-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center mb-8">
                <h1 class="text-3xl font-bold text-primary">Manage Cars</h1>
                <a href="add-car.php" class="bg-accent text-white px-6 py-3 rounded-lg hover:bg-orange-700 transition md:hidden">
                    <i class="fas fa-plus mr-2"></i>Add Car
                </a>
            </div>
           
            <?php if ($success): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded-lg mb-6 flex items-center">
                <i class="fas fa-check-circle mr-2"></i><?php echo $success; ?>
            </div>
            <?php endif; ?>
            <?php if ($error): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded-lg mb-6 flex items-center">
                <i class="fas fa-exclamation-circle mr-2"></i><?php echo $error; ?>
            </div>
            <?php endif; ?>
           
            <?php if (count($cars) > 0): ?>
            <div class="bg-white rounded-2xl shadow-xl overflow-hidden">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Car</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Views</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($cars as $car): ?>
                        <tr class="hover:bg-gray-50">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="font-medium text-gray-900"><?php echo clean($car['year'] . ' ' . $car['make'] . ' ' . $car['model']); ?></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-gray-500"><?php echo formatPrice($car['price']); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-semibold rounded-full <?php echo $car['status'] === 'available' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                    <?php echo ucfirst($car['status']); ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-gray-500"><?php echo $car['views']; ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <a href="edit-car.php?id=<?php echo $car['id']; ?>" class="text-accent hover:text-orange-700 mr-4">
                                    <i class="fas fa-edit mr-1"></i>Edit
                                </a>
                                <a href="delete-car.php?id=<?php echo $car['id']; ?>" onclick="return confirm('Are you sure you want to delete this car?');" class="text-red-600 hover:text-red-900">
                                    <i class="fas fa-trash mr-1"></i>Delete
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="bg-white rounded-2xl shadow-xl p-8 text-center">
                <i class="fas fa-car-side text-6xl text-gray-300 mb-4"></i>
                <p class="text-xl text-gray-500 mb-4">No cars added yet</p>
                <a href="add-car.php" class="bg-accent text-white px-6 py-3 rounded-lg hover:bg-orange-700 transition">
                    <i class="fas fa-plus mr-2"></i>Add Your First Car
                </a>
            </div>
            <?php endif; ?>
        </div>
    </section>
</body>
</html>