<?php
// admin/delete-car.php - Delete car
require_once '../config.php';
requireAuth();

$id = intval($_GET['id'] ?? 0);
if ($id > 0) {
    $db = getDB();
    // Delete images
    $stmt = $db->prepare("SELECT image_path, thumbnail FROM car_images WHERE car_id = ?");
    $stmt->execute([$id]);
    $images = $stmt->fetchAll();
    foreach ($images as $img) {
        @unlink('../' . $img['image_path']);
        if ($img['thumbnail']) @unlink('../' . $img['thumbnail']);
    }

    $stmt = $db->prepare("DELETE FROM car_images WHERE car_id = ?");
    $stmt->execute([$id]);

    $stmt = $db->prepare("DELETE FROM cars WHERE id = ?");
    $stmt->execute([$id]);

    setFlash('success', 'Car deleted successfully');
}
redirect('dashboard.php');
?>