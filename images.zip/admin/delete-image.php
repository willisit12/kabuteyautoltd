<?php
// admin/delete-image.php - Delete image
require_once '../config.php';
requireAuth();

$imageId = intval($_GET['id'] ?? 0);
$carId = intval($_GET['car_id'] ?? 0);

if ($imageId > 0 && $carId > 0) {
    $db = getDB();
    $stmt = $db->prepare("SELECT image_path, thumbnail, is_primary FROM car_images WHERE id = ? AND car_id = ?");
    $stmt->execute([$imageId, $carId]);
    $img = $stmt->fetch();

    if ($img) {
        @unlink('../' . $img['image_path']);
        if ($img['thumbnail']) @unlink('../' . $img['thumbnail']);

        $stmt = $db->prepare("DELETE FROM car_images WHERE id = ?");
        $stmt->execute([$imageId]);

        if ($img['is_primary']) {
            // Set new primary if exists
            $stmt = $db->prepare("UPDATE car_images SET is_primary = 1 WHERE car_id = ? ORDER BY display_order ASC LIMIT 1");
            $stmt->execute([$carId]);
        }

        setFlash('success', 'Image deleted successfully');
    } else {
        setFlash('error', 'Image not found');
    }
}
redirect('edit-car.php?id=' . $carId);
?>