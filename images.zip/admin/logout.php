<?php
// admin/logout.php - Logout
require_once '../config.php';

session_destroy();
setFlash('success', 'Logged out successfully');
redirect('../login.php');
?>