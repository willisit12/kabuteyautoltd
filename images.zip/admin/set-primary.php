<?php
// admin/set-primary.php - Set primary image
require_once '../config.php';
requireAuth();

$imageId = intval($_GET['id'] ?? 0);
$carId = intval($_GET['car_id'] ?? 0);

if ($imageId > 0 && $carId > 0) {
    $db = getDB();
    $stmt = $db->prepare("UPDATE car_images SET is_primary = 0 WHERE car_id = ?");
    $stmt->execute([$carId]);

    $stmt = $db->prepare("UPDATE car_images SET is_primary = 1 WHERE id = ? AND car_id = ?");
    $stmt->execute([$imageId, $carId]);

    setFlash('success', 'Primary image updated');
}
redirect('edit-car.php?id=' . $carId);
?>