<?php
// admin/edit-car.php - Form to edit car
require_once '../config.php';
requireAuth();

$id = intval($_GET['id'] ?? 0);
$car = getCarById($id);
if (!$car) {
    setFlash('error', 'Car not found');
    redirect('dashboard.php');
}

$error = getFlash('error');
$success = getFlash('success');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Invalid security token');
        redirect('edit-car.php?id=' . $id);
    }

    $data = [
        'make' => clean($_POST['make'] ?? ''),
        'model' => clean($_POST['model'] ?? ''),
        'year' => intval($_POST['year'] ?? 0),
        'price' => floatval($_POST['price'] ?? 0),
        'mileage' => intval($_POST['mileage'] ?? 0),
        'fuel_type' => clean($_POST['fuel_type'] ?? ''),
        'transmission' => clean($_POST['transmission'] ?? ''),
        'description' => clean($_POST['description'] ?? ''),
        'featured' => isset($_POST['featured']) ? 1 : 0,
        'status' => clean($_POST['status'] ?? 'available'),
    ];

    if (empty($data['make']) || empty($data['model']) || !validateYear($data['year']) || !validatePrice($data['price']) || empty($data['fuel_type']) || empty($data['transmission'])) {
        setFlash('error', 'Please fill all required fields correctly');
        redirect('edit-car.php?id=' . $id);
    }

    $db = getDB();
    $stmt = $db->prepare("UPDATE cars SET make = :make, model = :model, year = :year, price = :price, mileage = :mileage, fuel_type = :fuel_type, transmission = :transmission, description = :description, featured = :featured, status = :status WHERE id = :id");
    $data['id'] = $id;
    $stmt->execute($data);

    // Handle new image uploads
    if (isset($_FILES['images']) && count($_FILES['images']['name']) > 0) {
        $files = $_FILES['images'];
        $currentOrder = count($car['images']);
        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] === 0) {
                $file = [
                    'name' => $files['name'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'size' => $files['size'][$i],
                    'error' => $files['error'][$i]
                ];
                $upload = uploadCarImage($file, $id);
                if ($upload['success']) {
                    $isPrimary = (count($car['images']) + $i === 0) ? 1 : 0;
                    $stmt = $db->prepare("INSERT INTO car_images (car_id, image_path, thumbnail, is_primary, display_order) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$id, $upload['path'], $upload['thumbnail'], $isPrimary, $currentOrder + $i]);
                }
            }
        }
    }

    setFlash('success', 'Car updated successfully');
    redirect('edit-car.php?id=' . $id);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Car - <?php echo SITE_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e293b',
                        secondary: '#334155',
                        accent: '#ea580c',
                    },
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Admin Navigation -->
    <nav class="bg-primary text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <a href="../index.php" class="text-2xl font-bold">
                    <i class="fas fa-car text-accent mr-2"></i><?php echo SITE_NAME; ?> Admin
                </a>
                <div class="flex items-center space-x-6">
                    <a href="dashboard.php" class="hover:text-gray-300 transition">
                        <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                    </a>
                    <a href="logout.php" class="hover:text-gray-300 transition">
                        <i class="fas fa-sign-out-alt mr-2"></i>Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>
   
    <!-- Edit Car Form -->
    <section class="pt-24 pb-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center mb-8">
                <h1 class="text-3xl font-bold text-primary">Edit Car: <?php echo clean($car['year'] . ' ' . $car['make'] . ' ' . $car['model']); ?></h1>
                <a href="dashboard.php" class="text-accent hover:underline">
                    <i class="fas fa-arrow-left mr-2"></i>Back to Dashboard
                </a>
            </div>
           
            <?php if ($error): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded-lg mb-6 flex items-center">
                <i class="fas fa-exclamation-circle mr-2"></i><?php echo $error; ?>
            </div>
            <?php endif; ?>
            <?php if ($success): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded-lg mb-6 flex items-center">
                <i class="fas fa-check-circle mr-2"></i><?php echo $success; ?>
            </div>
            <?php endif; ?>
           
            <div class="bg-white rounded-2xl shadow-xl p-8 mb-12">
                <form method="POST" enctype="multipart/form-data" class="space-y-6">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                   
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Make *</label>
                            <input type="text" name="make" required value="<?php echo clean($car['make']); ?>" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Model *</label>
                            <input type="text" name="model" required value="<?php echo clean($car['model']); ?>" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                    </div>
                   
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Year *</label>
                            <input type="number" name="year" min="1900" max="<?php echo date('Y') + 1; ?>" required value="<?php echo $car['year']; ?>" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Price ($)*</label>
                            <input type="number" name="price" step="0.01" min="0" required value="<?php echo $car['price']; ?>" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Mileage (mi)*</label>
                            <input type="number" name="mileage" min="0" required value="<?php echo $car['mileage']; ?>" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                    </div>
                   
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Fuel Type *</label>
                            <select name="fuel_type" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                                <option value="Gasoline" <?php echo $car['fuel_type'] === 'Gasoline' ? 'selected' : ''; ?>>Gasoline</option>
                                <option value="Diesel" <?php echo $car['fuel_type'] === 'Diesel' ? 'selected' : ''; ?>>Diesel</option>
                                <option value="Electric" <?php echo $car['fuel_type'] === 'Electric' ? 'selected' : ''; ?>>Electric</option>
                                <option value="Hybrid" <?php echo $car['fuel_type'] === 'Hybrid' ? 'selected' : ''; ?>>Hybrid</option>
                            </select>
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Transmission *</label>
                            <select name="transmission" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                                <option value="Automatic" <?php echo $car['transmission'] === 'Automatic' ? 'selected' : ''; ?>>Automatic</option>
                                <option value="Manual" <?php echo $car['transmission'] === 'Manual' ? 'selected' : ''; ?>>Manual</option>
                            </select>
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Status *</label>
                            <select name="status" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                                <option value="available" <?php echo $car['status'] === 'available' ? 'selected' : ''; ?>>Available</option>
                                <option value="sold" <?php echo $car['status'] === 'sold' ? 'selected' : ''; ?>>Sold</option>
                            </select>
                        </div>
                    </div>
                   
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                        <textarea name="description" rows="6" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition"><?php echo clean($car['description']); ?></textarea>
                    </div>
                   
                    <div class="flex items-center">
                        <input type="checkbox" name="featured" id="featured" <?php echo $car['featured'] ? 'checked' : ''; ?> class="h-4 w-4 text-accent focus:ring-accent border-gray-300 rounded">
                        <label for="featured" class="ml-2 text-sm text-gray-700">Mark as Featured</label>
                    </div>
                   
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Add New Images</label>
                        <input type="file" name="images[]" multiple accept="image/jpeg,image/png,image/webp" class="w-full text-gray-500">
                        <p class="mt-2 text-sm text-gray-500">Max 5MB per image. New images will be added to the end.</p>
                    </div>
                   
                    <div class="flex justify-end space-x-4">
                        <a href="dashboard.php" class="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300 transition">
                            Cancel
                        </a>
                        <button type="submit" class="px-6 py-3 bg-accent text-white rounded-lg font-semibold hover:bg-orange-700 transition">
                            <i class="fas fa-save mr-2"></i>Update Car
                        </button>
                    </div>
                </form>
            </div>
           
            <!-- Images Management -->
            <?php if (count($car['images']) > 0): ?>
            <h2 class="text-2xl font-bold text-primary mb-6">Manage Images</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                <?php foreach ($car['images'] as $image): ?>
                <div class="bg-white rounded-lg shadow p-4">
                    <img src="../<?php echo clean($image['image_path']); ?>" alt="Car image" class="w-full h-48 object-cover rounded-md mb-4">
                    <div class="flex justify-between">
                        <a href="set-primary.php?id=<?php echo $image['id']; ?>&car_id=<?php echo $id; ?>" class="text-accent hover:underline <?php echo $image['is_primary'] ? 'font-bold' : ''; ?>">
                            <i class="fas fa-star mr-1"></i><?php echo $image['is_primary'] ? 'Primary' : 'Set Primary'; ?>
                        </a>
                        <a href="delete-image.php?id=<?php echo $image['id']; ?>&car_id=<?php echo $id; ?>" onclick="return confirm('Are you sure?');" class="text-red-600 hover:text-red-800">
                            <i class="fas fa-trash mr-1"></i>Delete
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p class="text-gray-500">No images uploaded yet. Add some above.</p>
            <?php endif; ?>
        </div>
    </section>
</body>
</html>