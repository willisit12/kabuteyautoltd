<?php
// admin/add-car.php - Form to add new car
require_once '../config.php';
requireAuth();

$error = getFlash('error');
$success = getFlash('success');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRFToken($_POST['csrf_token'] ?? '')) {
        setFlash('error', 'Invalid security token');
        redirect('add-car.php');
    }

    $data = [
        'make' => clean($_POST['make'] ?? ''),
        'model' => clean($_POST['model'] ?? ''),
        'year' => intval($_POST['year'] ?? 0),
        'price' => floatval($_POST['price'] ?? 0),
        'mileage' => intval($_POST['mileage'] ?? 0),
        'fuel_type' => clean($_POST['fuel_type'] ?? ''),
        'transmission' => clean($_POST['transmission'] ?? ''),
        'description' => clean($_POST['description'] ?? ''),
        'featured' => isset($_POST['featured']) ? 1 : 0,
        'status' => 'available',
        'views' => 0,
        'created_at' => date('Y-m-d H:i:s')
    ];

    if (empty($data['make']) || empty($data['model']) || !validateYear($data['year']) || !validatePrice($data['price']) || empty($data['fuel_type']) || empty($data['transmission'])) {
        setFlash('error', 'Please fill all required fields correctly');
        redirect('add-car.php');
    }

    $db = getDB();
    $stmt = $db->prepare("INSERT INTO cars (make, model, year, price, mileage, fuel_type, transmission, description, featured, status, views, created_at) VALUES (:make, :model, :year, :price, :mileage, :fuel_type, :transmission, :description, :featured, :status, :views, :created_at)");
    $stmt->execute($data);
    $carId = $db->lastInsertId();

    // Handle image uploads
    if (isset($_FILES['images']) && count($_FILES['images']['name']) > 0) {
        $files = $_FILES['images'];
        for ($i = 0; $i < count($files['name']); $i++) {
            if ($files['error'][$i] === 0) {
                $file = [
                    'name' => $files['name'][$i],
                    'tmp_name' => $files['tmp_name'][$i],
                    'size' => $files['size'][$i],
                    'error' => $files['error'][$i]
                ];
                $upload = uploadCarImage($file, $carId);
                if ($upload['success']) {
                    $isPrimary = $i === 0 ? 1 : 0;
                    $stmt = $db->prepare("INSERT INTO car_images (car_id, image_path, thumbnail, is_primary, display_order) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$carId, $upload['path'], $upload['thumbnail'], $isPrimary, $i]);
                }
            }
        }
    }

    setFlash('success', 'Car added successfully');
    redirect('dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Car - <?php echo SITE_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e293b',
                        secondary: '#334155',
                        accent: '#ea580c',
                    },
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Admin Navigation -->
    <nav class="bg-primary text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <a href="../index.php" class="text-2xl font-bold">
                    <i class="fas fa-car text-accent mr-2"></i><?php echo SITE_NAME; ?> Admin
                </a>
                <div class="flex items-center space-x-6">
                    <a href="dashboard.php" class="hover:text-gray-300 transition">
                        <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                    </a>
                    <a href="logout.php" class="hover:text-gray-300 transition">
                        <i class="fas fa-sign-out-alt mr-2"></i>Logout
                    </a>
                </div>
            </div>
        </div>
    </nav>
   
    <!-- Add Car Form -->
    <section class="pt-24 pb-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center mb-8">
                <h1 class="text-3xl font-bold text-primary">Add New Car</h1>
                <a href="dashboard.php" class="text-accent hover:underline">
                    <i class="fas fa-arrow-left mr-2"></i>Back to Dashboard
                </a>
            </div>
           
            <?php if ($error): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded-lg mb-6 flex items-center">
                <i class="fas fa-exclamation-circle mr-2"></i><?php echo $error; ?>
            </div>
            <?php endif; ?>
            <?php if ($success): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded-lg mb-6 flex items-center">
                <i class="fas fa-check-circle mr-2"></i><?php echo $success; ?>
            </div>
            <?php endif; ?>
           
            <div class="bg-white rounded-2xl shadow-xl p-8">
                <form method="POST" enctype="multipart/form-data" class="space-y-6">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                   
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Make *</label>
                            <input type="text" name="make" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Model *</label>
                            <input type="text" name="model" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                    </div>
                   
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Year *</label>
                            <input type="number" name="year" min="1900" max="<?php echo date('Y') + 1; ?>" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Price ($)*</label>
                            <input type="number" name="price" step="0.01" min="0" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Mileage (mi)*</label>
                            <input type="number" name="mileage" min="0" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        </div>
                    </div>
                   
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Fuel Type *</label>
                            <select name="fuel_type" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                                <option value="">Select Fuel Type</option>
                                <option value="Gasoline">Gasoline</option>
                                <option value="Diesel">Diesel</option>
                                <option value="Electric">Electric</option>
                                <option value="Hybrid">Hybrid</option>
                            </select>
                        </div>
                       
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Transmission *</label>
                            <select name="transmission" required class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition">
                                <option value="">Select Transmission</option>
                                <option value="Automatic">Automatic</option>
                                <option value="Manual">Manual</option>
                            </select>
                        </div>
                    </div>
                   
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                        <textarea name="description" rows="6" class="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-accent focus:border-transparent transition"></textarea>
                    </div>
                   
                    <div class="flex items-center">
                        <input type="checkbox" name="featured" id="featured" class="h-4 w-4 text-accent focus:ring-accent border-gray-300 rounded">
                        <label for="featured" class="ml-2 text-sm text-gray-700">Mark as Featured</label>
                    </div>
                   
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Images (up to 5, first one will be primary)</label>
                        <input type="file" name="images[]" multiple accept="image/jpeg,image/png,image/webp" class="w-full text-gray-500">
                        <p class="mt-2 text-sm text-gray-500">Max 5MB per image</p>
                    </div>
                   
                    <div class="flex justify-end space-x-4">
                        <a href="dashboard.php" class="px-6 py-3 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300 transition">
                            Cancel
                        </a>
                        <button type="submit" class="px-6 py-3 bg-accent text-white rounded-lg font-semibold hover:bg-orange-700 transition">
                            <i class="fas fa-save mr-2"></i>Add Car
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</body>
</html>