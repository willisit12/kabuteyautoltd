<?php
// car-details.php - Car details page with image carousel
require_once 'config.php';

$id = intval($_GET['id'] ?? 0);
$car = getCarById($id);

if (!$car) {
    http_response_code(404);
    require '404.php';
    exit;
}

// Get recommended cars
$recommendedCars = getRecommendedCars($id, 6);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo clean($car['year'] . ' ' . $car['make'] . ' ' . $car['model']); ?> - <?php echo SITE_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#1e293b',
                        secondary: '#334155',
                        accent: '#ea580c',
                    },
                    fontFamily: {
                        'inter': ['Inter', 'sans-serif']
                    }
                }
            }
        }
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <style>
        body { font-family: 'Inter', sans-serif; }
        
        /* Modal overlay styles */
        .image-modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.9);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }
        
        .image-modal.active {
            display: flex;
        }
        
        /* Modal open animation */
        @keyframes modalFadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
        
        /* Modal close animation */
        @keyframes modalFadeOut {
            from {
                opacity: 1;
            }
            to {
                opacity: 0;
            }
        }
        
        /* Image open animation */
        @keyframes imageZoomIn {
            from {
                opacity: 0;
                transform: scale(0.3);
            }
            to {
                opacity: 1;
                transform: scale(1);
            }
        }
        
        /* Image close animation */
        @keyframes imageZoomOut {
            from {
                opacity: 1;
                transform: scale(1);
            }
            to {
                opacity: 0;
                transform: scale(0.3);
            }
        }
        
        .image-modal.opening {
            animation: modalFadeIn 0.3s ease-out forwards;
        }
        
        .image-modal.closing {
            animation: modalFadeOut 0.3s ease-out forwards;
        }
        
        .image-modal-content.opening {
            animation: imageZoomIn 0.4s ease-out forwards;
        }
        
        .image-modal-content.closing {
            animation: imageZoomOut 0.3s ease-out forwards;
        }
        
        .image-modal-content {
            position: relative;
            max-width: 90vw;
            max-height: 90vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .image-modal-content img {
            max-width: 100%;
            max-height: 90vh;
            object-fit: contain;
        }
        
        .image-modal-close {
            position: absolute;
            top: 20px;
            right: 30px;
            font-size: 40px;
            color: white;
            cursor: pointer;
            z-index: 1001;
            transition: color 0.3s;
        }
        
        .image-modal-close:hover {
            color: #ea580c;
        }
        
        .swiper-slide img {
            cursor: pointer;
            transition: opacity 0.3s;
        }
        
        .swiper-slide img:hover {
            opacity: 0.8;
        }
        
        /* Recommended cars styles */
        .recommended-card {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(0, 0, 0, 0.05);
        }
        
        .recommended-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
            border-color: rgba(234, 88, 12, 0.2);
        }
        
        .recommended-image {
            overflow: hidden;
            transition: transform 0.4s ease;
        }
        
        .recommended-card:hover .recommended-image {
            transform: scale(1.05);
        }
        
        .section-title {
            position: relative;
            display: inline-block;
        }
        
        .section-title::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #ea580c, #d84a07);
            border-radius: 2px;
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg fixed w-full top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-20">
                <div class="flex items-center">
                    <a href="index.php">
                        <img src="images/logo-main.png" alt="<?php echo SITE_NAME; ?>" class="h-16 object-contain">
                    </a>
                </div>
               
                <div class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-accent transition font-medium">Home</a>
                    <a href="cars.php" class="text-gray-700 hover:text-accent transition font-medium">All Cars</a>
                    <a href="about.php" class="text-gray-700 hover:text-accent transition font-medium">About</a>
                    <a href="contact.php" class="text-gray-700 hover:text-accent transition font-medium">Contact</a>
                    <?php if (isLoggedIn()): ?>
                        <a href="admin/dashboard.php" class="bg-accent text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition">
                            <i class="fas fa-tachometer-alt mr-2"></i>Dashboard
                        </a>
                    <?php else: ?>
                        <a href="login.php" class="text-gray-700 hover:text-accent transition font-medium">
                            <i class="fas fa-user mr-1"></i>Admin
                        </a>
                    <?php endif; ?>
                </div>
               
                <!-- Mobile menu button -->
                <button id="mobile-menu-btn" class="md:hidden text-gray-700 hover:text-accent">
                    <i class="fas fa-bars text-2xl"></i>
                </button>
            </div>
        </div>
       
        <!-- Mobile menu -->
        <div id="mobile-menu" class="hidden md:hidden bg-white border-t">
            <div class="px-4 pt-2 pb-4 space-y-2">
                <a href="index.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Home</a>
                <a href="cars.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">All Cars</a>
                <a href="about.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">About</a>
                <a href="contact.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Contact</a>
                <?php if (isLoggedIn()): ?>
                    <a href="admin/dashboard.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Dashboard</a>
                <?php else: ?>
                    <a href="login.php" class="block px-3 py-2 text-gray-700 hover:bg-gray-100 rounded">Admin Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
   
    <!-- Car Details -->
    <section class="pt-32 pb-16 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <a href="javascript:history.back()" class="inline-flex items-center text-accent hover:underline mb-8">
                <i class="fas fa-arrow-left mr-2"></i>Back to Listings
            </a>
           
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
                <!-- Image Carousel -->
                <div class="animate__animated animate__fadeIn">
                    <div class="swiper detailSwiper rounded-2xl overflow-hidden shadow-xl">
                        <div class="swiper-wrapper">
                            <?php foreach ($car['images'] as $image): ?>
                            <div class="swiper-slide">
                                <img src="<?php echo clean($image['image_path']); ?>"
                                     alt="<?php echo clean($car['make'] . ' ' . $car['model']); ?>"
                                     class="w-full h-[500px] object-cover"
                                     loading="lazy">
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="swiper-button-next text-white"></div>
                        <div class="swiper-button-prev text-white"></div>
                        <div class="swiper-pagination"></div>
                    </div>
                   
                    <!-- Thumbnails -->
                    <?php if (count($car['images']) > 1): ?>
                    <div class="swiper thumbnailSwiper mt-4">
                        <div class="swiper-wrapper">
                            <?php foreach ($car['images'] as $image): ?>
                            <div class="swiper-slide cursor-pointer">
                                <img src="<?php echo clean($image['thumbnail'] ?? $image['image_path']); ?>"
                                     alt="Thumbnail"
                                     class="w-full h-24 object-cover rounded-lg border-2 border-transparent">
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
               
                <!-- Details -->
                <div class="lg:sticky lg:top-24 animate__animated animate__fadeInRight">
                    <h1 class="text-4xl font-bold text-primary mb-2">
                        <?php echo clean($car['year'] . ' ' . $car['make'] . ' ' . $car['model']); ?>
                    </h1>
                    <p class="text-3xl font-bold text-accent mb-8"><?php echo formatPrice($car['price']); ?></p>
                   
                    <div class="bg-gray-100 rounded-2xl p-6 mb-8">
                        <h2 class="text-2xl font-bold text-primary mb-4">Key Specifications</h2>
                        <dl class="grid grid-cols-2 gap-4 text-gray-700">
                            <dt class="font-medium">Year</dt>
                            <dd><?php echo clean($car['year']); ?></dd>
                            <dt class="font-medium">Mileage</dt>
                            <dd><?php echo formatMileage($car['mileage']); ?></dd>
                            <dt class="font-medium">Fuel Type</dt>
                            <dd><?php echo clean($car['fuel_type']); ?></dd>
                            <dt class="font-medium">Transmission</dt>
                            <dd><?php echo clean($car['transmission']); ?></dd>
                        </dl>
                    </div>
                   
                    <div class="mb-8">
                        <h2 class="text-2xl font-bold text-primary mb-4">Description</h2>
                        <p class="text-gray-600 leading-relaxed whitespace-pre-wrap"><?php echo clean($car['description']); ?></p>
                    </div>
                   
                    <a href="contact.php?car_id=<?php echo $car['id']; ?>"
                       class="block bg-accent text-white text-center py-4 rounded-lg font-semibold hover:bg-orange-700 transition md:sticky md:top-32">
                        <i class="fas fa-envelope mr-2"></i>Contact Seller
                    </a>
                </div>
            </div>
        </div>
    </section>
   
    <!-- Image Modal -->
    <div id="imageModal" class="image-modal">
        <span class="image-modal-close">&times;</span>
        <div class="image-modal-content">
            <img id="modalImage" src="" alt="Enlarged car image">
        </div>
    </div>
   
    <!-- Recommended Cars Section -->
    <?php if (count($recommendedCars) > 0): ?>
    <section class="py-20 bg-gray-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="mb-16">
                <h2 class="text-4xl md:text-5xl font-bold text-primary mb-4 section-title">You May Also Like</h2>
                <p class="text-gray-600 text-lg mt-8">Explore similar vehicles from our inventory</p>
            </div>
           
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach ($recommendedCars as $recCar):
                    $recImage = $recCar['primary_image'] ?? 'https://via.placeholder.com/400x300?text=No+Image';
                ?>
                <div class="recommended-card bg-white rounded-2xl overflow-hidden shadow-lg">
                    <div class="relative recommended-image h-56 overflow-hidden">
                        <img src="<?php echo $recImage; ?>"
                             alt="<?php echo clean($recCar['make'] . ' ' . $recCar['model']); ?>"
                             class="w-full h-full object-cover"
                             loading="lazy">
                        <?php if ($recCar['featured']): ?>
                        <div class="absolute top-4 left-4">
                            <span class="inline-flex items-center px-4 py-2 rounded-full text-sm font-semibold text-white bg-gradient-to-r from-accent to-orange-700">
                                <i class="fas fa-star mr-2"></i>Featured
                            </span>
                        </div>
                        <?php endif; ?>
                    </div>
                   
                    <div class="p-6">
                        <h3 class="text-xl font-bold text-primary mb-2">
                            <?php echo clean($recCar['year'] . ' ' . $recCar['make'] . ' ' . $recCar['model']); ?>
                        </h3>
                       
                        <div class="flex items-center justify-between mb-5">
                            <span class="text-2xl font-bold bg-gradient-to-r from-accent to-orange-700 bg-clip-text text-transparent">
                                <?php echo formatPrice($recCar['price']); ?>
                            </span>
                        </div>
                       
                        <div class="space-y-2 mb-6 pb-6 border-b border-gray-200">
                            <div class="flex items-center text-gray-600 text-sm">
                                <span class="inline-flex items-center justify-center w-8 h-8 rounded-full bg-accent bg-opacity-10 text-accent mr-3">
                                    <i class="fas fa-calendar text-xs"></i>
                                </span>
                                <span><?php echo $recCar['year']; ?></span>
                            </div>
                            <div class="flex items-center text-gray-600 text-sm">
                                <span class="inline-flex items-center justify-center w-8 h-8 rounded-full bg-accent bg-opacity-10 text-accent mr-3">
                                    <i class="fas fa-tachometer-alt text-xs"></i>
                                </span>
                                <span><?php echo formatMileage($recCar['mileage']); ?></span>
                            </div>
                            <div class="flex items-center text-gray-600 text-sm">
                                <span class="inline-flex items-center justify-center w-8 h-8 rounded-full bg-accent bg-opacity-10 text-accent mr-3">
                                    <i class="fas fa-gas-pump text-xs"></i>
                                </span>
                                <span><?php echo $recCar['fuel_type']; ?></span>
                            </div>
                        </div>
                       
                        <a href="car-details.php?id=<?php echo $recCar['id']; ?>"
                           class="block w-full bg-gradient-to-r from-accent to-orange-700 text-white text-center py-3 rounded-xl font-semibold hover:shadow-lg transition">
                            View Details <i class="fas fa-arrow-right ml-2"></i>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
   
    <!-- Footer -->
    <footer class="bg-primary text-white py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-2xl font-bold mb-4">
                        <i class="fas fa-car text-accent mr-2"></i><?php echo SITE_NAME; ?>
                    </h3>
                    <p class="text-gray-300">Your trusted partner in finding quality vehicles.</p>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Quick Links</h4>
                    <ul class="space-y-2">
                        <li><a href="index.php" class="text-gray-300 hover:text-accent transition">Home</a></li>
                        <li><a href="cars.php" class="text-gray-300 hover:text-accent transition">All Cars</a></li>
                        <li><a href="about.php" class="text-gray-300 hover:text-accent transition">About</a></li>
                        <li><a href="contact.php" class="text-gray-300 hover:text-accent transition">Contact</a></li>
                    </ul>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Contact</h4>
                    <ul class="space-y-2 text-gray-300">
                        <li><i class="fas fa-phone text-accent mr-2"></i>+233202493547</li>
                        <li><i class="fas fa-envelope text-accent mr-2"></i>kabuteyautoltd@gmail.com</li>
                        <li><i class="fas fa-map-marker-alt text-accent mr-2"></i>123 Auto St, City</li>
                    </ul>
                </div>
               
                <div>
                    <h4 class="text-lg font-semibold mb-4">Follow Us</h4>
                    <div class="flex space-x-4">
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-twitter"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-2xl text-gray-300 hover:text-accent transition"><i class="fab fa-linkedin"></i></a>
                    </div>
                </div>
            </div>
           
            <div class="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
                <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?>. All rights reserved.</p>
            </div>
        </div>
    </footer>
   
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
   
    <script>
        // Mobile menu toggle
        document.getElementById('mobile-menu-btn').addEventListener('click', function() {
            document.getElementById('mobile-menu').classList.toggle('hidden');
        });
        
        // Image Modal functionality
        const imageModal = document.getElementById('imageModal');
        const modalImage = document.getElementById('modalImage');
        const modalContent = document.querySelector('.image-modal-content');
        const closeBtn = document.querySelector('.image-modal-close');
        
        // Function to open modal with animation
        function openModal(imageSrc) {
            modalImage.src = imageSrc;
            imageModal.classList.add('active');
            imageModal.classList.add('opening');
            modalContent.classList.add('opening');
            
            // Remove animation classes after animation completes
            setTimeout(() => {
                imageModal.classList.remove('opening');
                modalContent.classList.remove('opening');
            }, 400);
        }
        
        // Function to close modal with animation
        function closeModal() {
            imageModal.classList.add('closing');
            modalContent.classList.add('closing');
            
            // Remove active class and animation classes after animation completes
            setTimeout(() => {
                imageModal.classList.remove('active', 'closing');
                modalContent.classList.remove('closing');
            }, 300);
        }
        
        // Get all swiper images
        const swiperImages = document.querySelectorAll('.detailSwiper .swiper-slide img');
        
        swiperImages.forEach(img => {
            img.addEventListener('click', function() {
                openModal(this.src);
            });
        });
        
        // Close modal when close button is clicked
        closeBtn.addEventListener('click', function() {
            closeModal();
        });
        
        // Close modal when clicking outside the image
        imageModal.addEventListener('click', function(event) {
            if (event.target === imageModal) {
                closeModal();
            }
        });
        
        // Close modal with Escape key
        document.addEventListener('keydown', function(event) {
            if (event.key === 'Escape' && imageModal.classList.contains('active')) {
                closeModal();
            }
        });
       
        // Detail Swiper
        const detailSwiper = new Swiper('.detailSwiper', {
            loop: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });
       
        // Thumbnail Swiper
        const thumbnailSwiper = new Swiper('.thumbnailSwiper', {
            slidesPerView: 4,
            spaceBetween: 10,
            watchSlidesProgress: true,
        });
       
        detailSwiper.controller.control = thumbnailSwiper;
        thumbnailSwiper.controller.control = detailSwiper;
    </script>
</body>
</html>